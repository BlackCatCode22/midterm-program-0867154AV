import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


// Main.java
// Driver class for the Zoo program
// dH
// 9/26/23

// updated Oct 5, 2023


public class Main {

    // Creating the genUniqueID method
    private static String genUniqueID(String theSpecies, int numOfSpecies) {
        String prefix = "";
        int suffix = numOfSpecies + 1;


        if (theSpecies.contains("hyena")) {
            prefix = "Hy";
        }

        return prefix + Integer.valueOf(suffix);

    }


    public static void main(String[] args) {

        // Load all species classes with name.
        // Call the static methods to create a lists of names.
        Lion.inputLionNames();
        Tiger.inputTigerNames();
        Bear.inputBearNames();
        Hyena.inputHyenaNames();



        // Open a csv file using the split() method on a string object
        String path = "C:\\Users\\BE218\\javaDataFiles\\arrivingAnimals.txt";
        String myFileLine = "";

        System.out.println("\n\n Welcome to the Zoo Program!");

        try {
            BufferedReader reader = new BufferedReader(new FileReader(path));
            int myCounter = 1;
            while ((myFileLine = reader.readLine()) != null) {

                // Create a String array

                String[] myArrayOfAnimalData = myFileLine.split(",");

                // Create another String array named

                String [] myArrayOfAgeGenderSpecies = myArrayOfAnimalData[0].split(" ");

                // Output age, gender and species.

                System.out.println("\n age in years: " + myArrayOfAgeGenderSpecies[0]);
                System.out.println("\n text for age (should be 'year') " + myArrayOfAgeGenderSpecies[1]);
                System.out.println("\n text for age (should be 'old') " + myArrayOfAgeGenderSpecies[2]);
                System.out.println("\n species is " + myArrayOfAgeGenderSpecies[3]);

                // Code of the BirthDate() method
                Date currentDate = new Date();

                // Create a calendar instance and set it to today's date
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(currentDate);

                // Subtract 4 years from the date
                calendar.add(Calendar.YEAR, - Integer.parseInt(myArrayOfAgeGenderSpecies[0]));

                // Get the result as a Date object
                Date YearsAgo = calendar.getTime();

                // Format and print the result
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = dateFormat.format(YearsAgo);
                System.out.println("Today's Date: " + dateFormat.format(currentDate));
                System.out.println("Date " +myArrayOfAgeGenderSpecies[0] + " Years Ago: " + formattedDate);



                System.out.println("\n Animal Number " + myCounter + "*************");
                System.out.println("\n myArrayOfAnimalData[0] is.... " + myArrayOfAnimalData[0]);
                System.out.println("\n myArrayOfAnimalData[1] is.... " + myArrayOfAnimalData[1]);
                System.out.println("\n myArrayOfAnimalData[2] is.... " + myArrayOfAnimalData[2]);
                System.out.println("\n myArrayOfAnimalData[3] is.... " + myArrayOfAnimalData[3]);
                System.out.println("\n myArrayOfAnimalData[4] is.... " + myArrayOfAnimalData[4]);
                System.out.println("\n myArrayOfAnimalData[5] is.... " + myArrayOfAnimalData[5]);
                System.out.println("\n\n");

                // increment counter
                myCounter++;

                /*String myStr = myArray[0];
                System.out.println("\n myStr = " + myStr);
                myArray = myStr.split(" ");
                String mySpecies = myArray[4];
                System.out.println(" Species is: " + mySpecies);
                System.out.println("\n myStr = " + myStr);


               /*
                System.out.println(" First element: " + myArray[0]);
                System.out.println(" Second element: " + myArray[1]);
                System.out.println(" Third item: " + myArray[2]);
                System.out.println(" Fourth element: " + myArray[3]);
                System.out.println(" Fifth item: " + myArray[4]);
                System.out.println(" Sixth item: " + myArray[5]);

                */
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }




}

