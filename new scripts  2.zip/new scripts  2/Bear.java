// "public" behind static means script is going to be accessible by other classes
// Constructor is method that initializes another method
// "Extends" is a term that is used to create a child from another class
// "private" and "public" method protect specific ints so that other programs do not reach out for these values and cause an interference.
//

import java.io.*;
import java.util.Scanner;

public class Bear extends Animal  {
    // create a static member variable that accumulates the number of hyenas created

    public static int numOfBears = 0;

    // create constructor that increments "numOfHyenas" when new hyena object is created

    public Bear() {

        System.out.println("\n A new Hyena object was created!");
        numOfBears++;
    }

    // create method that inputs hyena names from the file: animalNames.txt
    public static void inputHyenaNames(){
        // open text file
        String filePath ="C:\\Users\\BE218\\Desktop\\arrivingAnimals.txt";

        try (BufferedReader fileReader = new BufferedReader(new FileReader(filePath));
             Scanner scanner = new Scanner(System.in)) {
            String line;
            System.out.println("Press enter to read the next line");
            while ((line = fileReader.readLine()) != null){
                System.out.println(line);
                String userInput = scanner.nextLine();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }




    //Write getter method
    public static int getNumOfBears() {
        return numOfBears;
    }
}
