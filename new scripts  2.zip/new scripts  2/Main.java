// Hyena anotherNewHy = new Hyena();
// anotherNewHy.assignName();
// class Hyena extends......
// public string assignName();
// Should method "assign name" belong to object or class
// assignName(); should be in one class
// Hyena object is to be created in this class
//
//
public class Main {

    // create the genUniqueID method

    private static String genUniqueID(String theSpecies, int numOfSpecies){
        String prefix = "";

        int suffix = numOfSpecies + 1;

        if (theSpecies.contains("hyena")){
            prefix = "Hy";
        }

        return prefix + Integer.valueOf(suffix);
    }

    public static void main(String[] args) {

        System.out.println("\n\n Welcome to my Zoo!\n\n");

        // call for Hyena names
        Hyena.inputHyenaNames();

        // Create new Hyena object

        Hyena myNewHyena = new Hyena();

        System.out.println("\n\n Number of Animals is " + myNewHyena.getNumOfAnimals());

        Hyena anotherHyena = new Hyena();

        System.out.println("\n\n Number of Animals is " + myNewHyena.getNumOfAnimals());

        System.out.println("\n\n Number of Hyenas " + anotherHyena.getNumOfHyenas());

        // call for Lion names
        Bear myNewBear = new Bear();

        System.out.println("\n\n Number of Animals is " + myNewBear.getNumOfAnimals());

        Bear anotherBear = new Bear();

        System.out.println("\n\n Number of Animals is " + myNewBear.getNumOfAnimals());

        System.out.println("\n\n Number of Bears " + anotherBear.getNumOfBears());


        // Create new Lion object

        Lion myNewLion = new Lion();

        System.out.println("\n\n Number of Animals is " + myNewLion.getNumOfAnimals());

        Lion anotherLion = new Lion();

        System.out.println("\n\n Number of Animals is " + myNewLion.getNumOfAnimals());

        System.out.println("\n\n Number of Hyenas " + anotherLion.getNumOfLions());

        Hyena oneMore = new Hyena();

        oneMore.setAnimalID("Hy09");

        System.out.println("\n The id of oneMore is " + oneMore.getAnimalID());

        oneMore.setAnimalColor("yellow spots");

        System.out.println("\n My Hyena color is " + oneMore.getAnimalColor());






    }




}