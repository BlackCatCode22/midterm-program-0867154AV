// you can use multiple constructors
// "private" and "public" method protect specific "ints" so that other programs do not reach out for these values and cause interference.
// This is almost the midterm, Functions are needed now.
// create unique id
public class Animal {

    private static int numOfAnimals = 0;

    private String animalID;
    private String animalName;

    private String animalBirthDate;

    private String animalColor;

    private char animalGender;

    private float animalWeight;

    private String arrivingFrom;

    // create getter/setters

    public String getAnimalID () {
        return animalID;
    }

    public void setAnimalID(String animalID) {
        this.animalID = animalID;
    }

    public int getNumOfAnimals() {
        return numOfAnimals;
    }


    // Constructor

    public Animal () {

        System.out.println("\n\n A new animal was created!");
        numOfAnimals++;

    }

    public String getAnimalName() {
        return animalName;

    }

    public void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

    public String getAnimalBirthDate() {
        return animalBirthDate;
    }

    public String getAnimalColor() {
        return animalColor;
    }

    public void setAnimalColor(String animalColor) {
        this.animalColor = animalColor;
    }

    public void setAnimalGender(char animalGender) {
        this.animalGender = animalGender;
    }

    public void setAnimalWeight(float animalWeight) {
        this.animalWeight = animalWeight;
    }

    public String getArrivingFrom() {
        return arrivingFrom;
    }

}
