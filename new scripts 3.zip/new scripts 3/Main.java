import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

// Hyena anotherNewHy = new Hyena();
// anotherNewHy.assignName();
// class Hyena extends......
// public string assignName();
// Should method "assign name" belong to object or class
// assignName(); should be in one class
// Hyena object is to be created in this class
//
//
public class Main {

    // create the genUniqueID method

    private static String genUniqueID(String theSpecies, int numOfSpecies){
        String prefix = "";

        int suffix = numOfSpecies + 1;

        if (theSpecies.contains("hyena")){
            prefix = "Hy";
        }

        return prefix + Integer.valueOf(suffix);
    }

    public static void main(String[] args) {

        System.out.println("\n\n Welcome to my Zoo!\n\n");


        // Create new Hyena object

        Hyena myNewHyena = new Hyena();

        System.out.println("\n\n Number of Animals is " + myNewHyena.getNumOfAnimals());

        Hyena anotherHyena = new Hyena();

        System.out.println("\n\n Number of Animals is " + myNewHyena.getNumOfAnimals());

        System.out.println("\n\n Number of Hyenas " + anotherHyena.getNumOfHyenas());



        // call for Bear names
        Bear myNewBear = new Bear();

        System.out.println("\n\n Number of Animals is " + myNewBear.getNumOfAnimals());

        Bear anotherBear = new Bear();

        System.out.println("\n\n Number of Animals is " + myNewBear.getNumOfAnimals());

        System.out.println("\n\n Number of Bears " + anotherBear.getNumOfBears());


        // Create new Lion object

        Lion myNewLion = new Lion();

        System.out.println("\n\n Number of Animals is " + myNewLion.getNumOfAnimals());

        Lion anotherLion = new Lion();

        System.out.println("\n\n Number of Animals is " + myNewLion.getNumOfAnimals());

        System.out.println("\n\n Number of Lions " + anotherLion.getNumOfLions());

        // Create new Tiger object

        Tiger myNewTiger = new Tiger();

        System.out.println("\n\n Number of Animals is " + myNewTiger.getNumOfAnimals());

        Tiger anotherTiger = new Tiger();

        System.out.println("\n\n Number of Animals is " + myNewTiger.getNumOfAnimals());

        System.out.println("\n\n Number of Tigers " + anotherTiger.getNumOfTigers());

        // hyena object

        Hyena oneMore = new Hyena();

        oneMore.setAnimalID("Hy09");

        System.out.println("\n The id of this animal is " + oneMore.getAnimalID());

        oneMore.setAnimalColor("yellow spots");

        System.out.println("\n My Hyena color is " + oneMore.getAnimalColor());

    }


    {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader("C:\\Users\\BE218\\Desktop\\arrivingAnimals.txt"));
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        }
        String myLine;
        System.out.println("Press enter to read the next line");

        while (true) {

            String line;
            try {
                if (!((line = reader.readLine()) != null)) break;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            
            System.out.println(line);
            Scanner scanner = null;
            String userInput = scanner.nextLine();
        }
    }
    
}