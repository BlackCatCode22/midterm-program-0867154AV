// you can use multiple constructors
// "private" and "public" method protect specific "ints" so that other programs do not reach out for these values and cause interference.
// This is almost the midterm, Functions are needed now.
//
public class Animal {

    private static int numOfAnimals = 0;

    // create getter
    // what type of method is this/ is it static ad belongs to a class or....
    // is this method used with objects?

    public int getNumOfAnimals() {
        return numOfAnimals;
    }


    // Constructor

    public Animal () {

        System.out.println("\n\n A new animal was created!");
        numOfAnimals++;

    }

}
