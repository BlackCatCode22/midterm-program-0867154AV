// Hyena anotherNewHy = new Hyena();
// anotherNewHy.assignName();
// class Hyena extends......
// public string assignName();
// Should method "assign name" belong to object or class
// assignName(); should be in one class
// Hyena object is to be created in this class
//
//
public class Main {
    public static void main(String[] args) {

        System.out.println("\n\n Welcome to my Zoo!\n\n");

        // call for names
        Hyena.inputHyenaNames();

        // Create new Hyena object

        Hyena myNewHyena = new Hyena();

        System.out.println("\n\n Number of Animals is " + myNewHyena.getNumOfAnimals());

        Hyena anotherHyena = new Hyena();

        System.out.println("\n\n Number of Animals is " + myNewHyena.getNumOfAnimals());

        System.out.println("\n\n Number of Hyenas " + anotherHyena.getNumOfHyenas());




    }
}